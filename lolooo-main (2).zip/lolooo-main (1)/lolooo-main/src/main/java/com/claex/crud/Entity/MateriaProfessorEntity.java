package com.claex.crud.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "tbl_materia_professor")

public class MateriaProfessorEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_professor")
    private CadastroEntity professor;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_materia")
    private MateriaEntity materia;

    @Column(nullable = false)
    private String nivelEnsino;

    @Column(nullable = false)
    private String experiencia;

    @Column(length = 500)
    private String descricao;
}

