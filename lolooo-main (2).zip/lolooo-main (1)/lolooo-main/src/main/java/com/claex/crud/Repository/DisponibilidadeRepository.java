package com.claex.crud.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.claex.crud.Entity.DisponibilidadeEntity;

public interface DisponibilidadeRepository extends JpaRepository<DisponibilidadeEntity, Long> {
    List<DisponibilidadeEntity> findByProfessorId(Long idProfessor);
    List<DisponibilidadeEntity> findByProfessorIdAndDiaSemana(Long idProfessor, String diaSemana);
}