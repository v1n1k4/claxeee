package com.claex.crud.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.claex.crud.Entity.MateriaProfessorEntity;

public interface MateriaProfessorRepository extends JpaRepository<MateriaProfessorEntity, Long> {
    List<MateriaProfessorEntity> findByProfessorId(Long idProfessor);
    boolean existsByProfessorIdAndMateriaIdMateria(Long idProfessor, Long idMateria);
}