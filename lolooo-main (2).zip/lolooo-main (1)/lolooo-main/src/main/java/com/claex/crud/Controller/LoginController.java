package com.claex.crud.Controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.claex.crud.Entity.CadastroEntity;
import com.claex.crud.Repository.CadastroRepository;

import jakarta.servlet.http.HttpSession;

@CrossOrigin(origins = "*") // Libera chamadas AJAX vindas do HTML/Live Server
@RestController
@RequestMapping("/login")
public class LoginController {

    @Autowired
    private CadastroRepository repository;

    @PostMapping("/entrar")
    public ResponseEntity<Map<String, String>> login(
            @RequestParam String login,
            @RequestParam String senha,
            HttpSession session) {

        // Corrigido: ponto e vírgula removido do final da linha abaixo
        Optional<CadastroEntity> usuarioOpt = repository.findByNome(login)
                .or(() -> repository.findByEmail(login));

        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("erro", "Usuário não cadastrado!"));
        }

        CadastroEntity usuario = usuarioOpt.get();

        if (!usuario.getSenha().equals(senha)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("erro", "Senha incorreta!"));
        }

        // Salva o usuário na sessão do servidor
        session.setAttribute("usuarioLogado", usuario);

        return ResponseEntity.ok(Map.of(
                "mensagem", "Login realizado com sucesso!",
                "nome", usuario.getNome(),
                "tipo", usuario.getTipo()
        ));
    }
}