/**
 * CLAEX API CLIENT BRIDGE & ROLE CONTROL
 */
(function () {
    'use strict';
    let usuarioAtual = null;

    window.API = {
        getUsuarioAtual() {
            if (!usuarioAtual) {
                const salvo = sessionStorage.getItem('claex_user');
                if (salvo) usuarioAtual = JSON.parse(salvo);
            }
            return usuarioAtual;
        },

        setUsuarioAtual(user) {
            usuarioAtual = user;
            sessionStorage.setItem('claex_user', JSON.stringify(user));
        },

        logout() {
            sessionStorage.removeItem('claex_user');
            window.location.href = 'form_login.html';
        },

        // Proteção de rotas no Frontend por perfil
        protegerPagina(tiposPermitidos = []) {
            const user = window.API.getUsuarioAtual();
            
            if (!user) {
                alert("Acesso restrito. Faça login para continuar.");
                window.location.href = "form_login.html";
                return false;
            }

            const tipoUser = (user.tipo || '').toLowerCase();
            const permitidos = tiposPermitidos.map(t => t.toLowerCase());

            if (permitidos.length > 0 && !permitidos.includes(tipoUser)) {
                alert("Seu perfil de usuário (" + user.tipo + ") não tem permissão para acessar esta página.");
                window.location.href = "listar_sala.html";
                return false;
            }
            return true;
        },

        // Endpoints de Cadastros e Autenticação
        cadastros: {
            async salvar(nome, email, senha, tipo) {
                const params = new URLSearchParams({ nome, email, senha, tipo });
                const response = await fetch(`/form_cadastro-html/salvar?${params.toString()}`, { method: 'POST' });
                const text = await response.text();
                return { ok: response.ok, msg: text, status: response.status };
            },
            async listar() {
                const response = await fetch('/form_cadastro-html/listar');
                if (!response.ok) throw new Error('Erro ao listar cadastros');
                return await response.json();
            },
            async atualizar(id, nome, senha, tipo) {
                const params = new URLSearchParams({ nome, senha, tipo });
                const response = await fetch(`/form_cadastro-html/atualizar/${id}?${params.toString()}`, { method: 'PUT' });
                return { ok: response.ok };
            },
            async deletar(id) {
                const response = await fetch(`/form_cadastro-html/deletar/${id}`, { method: 'DELETE' });
                return { ok: response.ok };
            }
        },

        async login(login, senha) {
            const params = new URLSearchParams({ login, senha });
            const response = await fetch(`/login/entrar?${params.toString()}`, { method: 'POST' });
            let data = {};
            try { data = await response.json(); } catch (e) {}
            if (response.ok) {
                window.API.setUsuarioAtual(data);
            }
            return { ok: response.ok, status: response.status, data: data };
        },

        // Endpoints de Salas
        salas: {
            async listar() {
                const response = await fetch('/salas/listar');
                if (!response.ok) throw new Error('Erro ao listar salas');
                return await response.json();
            },
            async buscarPorId(id) {
                const response = await fetch(`/salas/${id}`);
                if (!response.ok) throw new Error('Sala não encontrada');
                return await response.json();
            },
            async salvar(sala) {
                const response = await fetch('/salas/salvar', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(sala)
                });
                if (!response.ok) throw new Error('Erro ao salvar sala');
                return await response.json();
            },
            async atualizar(id, sala) {
                const response = await fetch(`/salas/${id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(sala)
                });
                if (!response.ok) throw new Error('Erro ao atualizar sala');
                return await response.json();
            },
            async deletar(id) {
                const response = await fetch(`/salas/${id}`, { method: 'DELETE' });
                return { ok: response.ok };
            }
        },

        // Endpoints de Matérias
        materias: {
            async listar() {
                const response = await fetch('/materias/listar');
                if (!response.ok) return [];
                return await response.json();
            }
        },

        // Endpoints de Professores
        professores: {
            async listar() {
                const response = await fetch('/professores/listar');
                if (!response.ok) return [];
                return await response.json();
            }
        },

        // Endpoints de Grade Horária
        grade: {
            async buscar(idSala) {
                const response = await fetch(`/grade/buscar/${idSala}`);
                if (!response.ok) throw new Error('Grade não encontrada');
                return await response.json();
            },
            async gerar(idSala, materiasPayload) {
                const response = await fetch(`/grade/gerargrade/${idSala}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(materiasPayload)
                });
                return { ok: response.ok };
            }
        }
    };
})();