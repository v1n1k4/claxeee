package com.claex.crud.Entity;

import java.time.LocalTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "tbl_disponibilidade_professor")

public class DisponibilidadeEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_professor")
    private CadastroEntity professor;

    @Column(nullable = false, length = 20)
    private String diaSemana; // Segunda-feira a domingo

    @Column(nullable = false)
    private LocalTime horarioInicial;

    @Column(nullable = false)
    private LocalTime horarioFinal;

    @Column(nullable = false, length = 20)
    private String modalidade; // Presencial, On-line, Ambas

    @Column(length = 255)
    private String observacao;

    @Column(nullable = false, length = 20)
    private String status = "Disponível"; // Disponível, Indisponível
    
}
