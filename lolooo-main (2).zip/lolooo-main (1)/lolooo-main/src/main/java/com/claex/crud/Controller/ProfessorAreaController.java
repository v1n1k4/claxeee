package com.claex.crud.Controller;

import com.claex.crud.Entity.CadastroEntity;
import com.claex.crud.Entity.DisponibilidadeEntity;
import com.claex.crud.Entity.MateriaProfessorEntity;
import com.claex.crud.Service.DisponibilidadeService;
import com.claex.crud.Service.MateriaProfessorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/professor")

public class ProfessorAreaController {
    @Autowired
    private DisponibilidadeService disponibilidadeService;

    @Autowired
    private MateriaProfessorService materiaProfessorService;

    // --- DISPONIBILIDADE ---
    @GetMapping("/disponibilidade")
    public ResponseEntity<List<DisponibilidadeEntity>> listarMinhaDisponibilidade(
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        return ResponseEntity.ok(disponibilidadeService.listarPorProfessor(professorLogado.getId()));
    }

    @PostMapping("/disponibilidade")
    public ResponseEntity<?> salvarDisponibilidade(
            @RequestBody DisponibilidadeEntity d,
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        try {
            return ResponseEntity.ok(disponibilidadeService.cadastrar(d, professorLogado));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/disponibilidade/{id}")
    public ResponseEntity<?> deletarDisponibilidade(
            @PathVariable Long id,
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        disponibilidadeService.remover(id, professorLogado);
        return ResponseEntity.ok("Disponibilidade removida com sucesso!");
    }

    // --- MINHAS MATÉRIAS ---
    @GetMapping("/materias")
    public ResponseEntity<List<MateriaProfessorEntity>> listarMinhasMaterias(
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        return ResponseEntity.ok(materiaProfessorService.listarPorProfessor(professorLogado.getId()));
    }

    @PostMapping("/materias")
    public ResponseEntity<?> vincularMateria(
            @RequestBody MateriaProfessorEntity mp,
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        return ResponseEntity.ok(materiaProfessorService.vincular(mp, professorLogado));
    }

    @DeleteMapping("/materias/{id}")
    public ResponseEntity<?> desvincularMateria(
            @PathVariable Long id,
            @AuthenticationPrincipal CadastroEntity professorLogado) {
        materiaProfessorService.remover(id, professorLogado);
        return ResponseEntity.ok("Matéria desvinculada com sucesso!");
    }
    
}
