package com.claex.crud.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                // LIBERA CADASTRO, LOGIN, STATIC E HTMLS
               .requestMatchers("/login/**", "/form_cadastro-html/**", "/css/**", "/js/**", "/*.html", "/").permitAll()
                .anyRequest().authenticated()
                
                // Regras por perfil
                .requestMatchers(HttpMethod.POST, "/salas/**").hasRole("ADMINISTRADOR")
                .requestMatchers(HttpMethod.PUT, "/salas/**").hasRole("ADMINISTRADOR")
                .requestMatchers(HttpMethod.DELETE, "/salas/**").hasRole("ADMINISTRADOR")
                .requestMatchers("/admin/**").hasRole("ADMINISTRADOR")
                .requestMatchers("/professor/**").hasRole("PROFESSOR")
                .requestMatchers(HttpMethod.GET, "/salas/**").hasAnyRole("ALUNO", "PROFESSOR", "ADMINISTRADOR")
                
                .anyRequest().authenticated()
            )
            .exceptionHandling(e -> e.accessDeniedHandler((req, res, ex) -> {
                res.setStatus(403);
                res.getWriter().write("{\"erro\": \"Acesso negado: Perfil sem permissão para esta operação.\"}");
            }));
            
        return http.build();
    }
}
